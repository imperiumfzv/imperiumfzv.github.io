library(pROC)
library(caret)
library(ROCR)
library(MLmetrics)

library(glmnet)
library(xgboost)   
library(randomForest)
library(lightgbm)
library(dplyr)

library(parallel)
# library(foreach)
# library(doSNOW)

library(relaimpo) #za lm

source("getPerformance.R")

eval_lm <- data.frame(Actual = "Actual", Predicted = "Predicted", Dataset = "Dataset", Seed = "Seed")
write.table(eval_lm,file = "lm_var_imp.csv", row.names = F, col.names = T)


evalLM <-function(X, Y, Xt, Yt, dataset_name, rnd_seed, onlyRegression = FALSE, returnFit = FALSE){ # , pen, pmax=NULL

  # feature selection 
  # # Starost - age
  # # Spol - gender
  # # Obseg.pasu - waist_circumference
  # # v2  -   Physical activity  30min/day?
  # # v3  -   Taking hypertension drugs?
  # # v4  -   High blood sugar history?
  # # v6  -   Diabetes in family
  # # (v5 -  "Fruit and vegetables consumption?" was not included in SloRisk)
  
  include_features = c("Starost", "Spol", "Obseg.pasu", "FR_V2", "FR_V3", "FR_V4", "FR_V6")
  X = X[include_features]
  Xt = Xt[include_features]
  
  # build model
  fit <- NULL
  set.seed(rnd_seed)
  
  Xt = as.data.frame(Xt)
  Y = data.frame(class = Y)
  X = as.data.frame(X)
  data = cbind(X,Y)
  
  try(fit <- lm(class~., data = data))
  
  threshold <- 0.05
  signif_names = names(which((summary(fit)$coefficients[
    2:(nrow(summary(fit)$coefficients)), 4] < threshold) == TRUE))
  sm_fit = summary(fit)
  data_coef = sm_fit$coefficients[row.names(sm_fit$coefficients) %in% signif_names,]

  abs_coef = abs(data_coef[,1])
  imp_val = sort(abs_coef, decreasing=TRUE)
  
  Var_name = names(imp_val)
  Var_value = as.double(imp_val)
  variables = Var_name
  numSelected <- length(Var_name)
  
  # relImportance <- calc.relimp(fit, type = "lmg", rela = TRUE)  # calculate relative importance scaled to 100
  # variables = names(sort(relImportance$lmg, decreasing=TRUE))  # relative importance
  # numSelected <- length(variables)
  # 
  # ############ save values ###############
  # imp_val = sort(relImportance$lmg, decreasing=TRUE)
  # Var_name = names(imp_val)
  # Var_value = as.double(imp_val)
  # ############   ############   ###########
  
  if (is.null(fit)) { # it might be null
    return(NULL)
  }
  if (returnFit) {
    return(fit)
  }

  # Predict on test set
  predMin <- predict(fit, type="response", Xt)
  
  if(onlyRegression){
    performance = getPerformance_regression(predMin, Yt)
  }else{
    performance = getPerformance(predMin, Yt)
  }

  if(is.null(performance)){
    return(NULL)
  }

  # save data ACTUAL vs PREDICTED
  eval_lm <- data.frame(Actual = Var_name, Predicted = Var_value, Dataset = dataset_name, Seed = rnd_seed )
  # eval_lm <- data.frame(Actual = Yt, Predicted = predMin, Dataset = dataset_name, Seed = rnd_seed)
  write.table(eval_lm,file = "lm_var_imp.csv", append = T, row.names = F, col.names = F)

  # print(data.frame(Name=dataset_name,
  #                  RMSE=performance[["RMSE"]],
  #                  MAE =performance[["MAE"]],
  #                  R_2 =performance[["r_squared"]],
  #                  NumSelected=numSelected,
  #                  YLength=nrow(Y), YtLength=length(Yt),
  #                  YSum=sum(Y), YtSum=sum(Yt)))
  
  if (onlyRegression) {
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],
                       NumSelected=numSelected,
                       YLength=nrow(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt),
                       Pred_Vars=paste(variables,sep="",collapse=","), stringsAsFactors = F)
  }else{
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],
                       # THRES_DT2 = performance[["THRES_DT2"]],
                       THRES_preDT2 = performance[["THRES_preDT2"]],
                       # AUC_DT2=performance[["AUC_DT2"]],
                       AUC_preDT2=performance[["AUC_preDT2"]],
                       
                       # AUPRC_DT2=performance[["AUPRC_DT2"]],
                       AUPRC_preDT2=performance[["AUPRC_preDT2"]],
                       
                       # F1_DT2=performance[["F1_DT2"]],
                       F1_preDT2=performance[["F1_preDT2"]],
                       
                       # SENS_DT2=performance[["SENS_DT2"]],
                       SENS_preDT2=performance[["SENS_preDT2"]],
                       
                       # PPV_DT2=performance[["PPV_DT2"]],
                       PPV_preDT2=performance[["PPV_preDT2"]],  
                       
                       NPV_preDT2=performance[["NPV_preDT2"]],              
                       SPEC_preDT2=performance[["SPEC_preDT2"]],
                       percPos = performance[["percPos"]],
                       
                       NumSelected=numSelected,
                       YLength=nrow(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt),
                       Pred_Vars=paste(variables,sep="",collapse=","), stringsAsFactors = F)
  }
  return(output)
}

eval_glmnet <- data.frame(Actual = "Actual", Predicted = "Predicted", Dataset = "Dataset", Seed = "Seed")
write.table(eval_glmnet,file = "glmnet_var_imp.csv", append = T, row.names = F, col.names = T)

## Evaluate LASSO (via GLMNET)
evalGLMNET <- function(X, Y, Xt, Yt, alpha, dataset_name, rnd_seed, pen, onlyRegression=FALSE, returnFit = FALSE) {
  # ptm <- proc.time()
  
  # build model
  fit <- NULL
  set.seed(rnd_seed)
  try(fit <- cv.glmnet(X, Y, family="gaussian", type="mae", nfolds=5, alpha=1))

  if(is.null(fit)) return(NULL)
  
  if (returnFit) {
    return(fit)
  }
  # time <- proc.time()-ptm
  # print(time)

  # Count selected features
  numSelectedMin <- fit$nzero[which(fit$lambda == fit$lambda.min)]
  
  # Predict on test set
  predMin <- predict(fit, type="response", Xt, s="lambda.min")

  # c<-coef(fit,s='lambda.min',exact=TRUE)
  # 
  # # you can take the absolute value of the final coefficients and rank them. The ranked coefficients are your variable importance.
  # c <- abs(c[rownames(c) != "(Intercept)",,drop = FALSE])

  ##### STANDARDIZE COEF.
  # if X is the input matrix of the glmnet function,
  # and fit is your glmnet object:
  sds <- apply(X, 2, sd)
  cs <- as.matrix(coef(fit, s = "lambda.min"))
  std_coefs <- cs[-1, 1] * sds
  c <- std_coefs
  #####

  ############ save values ###############
  Var_value = c[order(c,decreasing = T)]
  variables = names(Var_value)
  Var_name = variables
  Var_value = as.double(Var_value)
  ############   ############   ###########

  if(onlyRegression){
    performance = getPerformance_regression(predMin, Yt)
  }else{
    performance = getPerformance(predMin, Yt)
  }
  
  if(is.null(performance)){
    return(NULL)
  }
  
  # save data ACTUAL vs PREDICTED
  eval_glmnet <- data.frame(Actual = Var_name, Predicted = Var_value, Dataset = dataset_name, Seed = rnd_seed )
  # eval_glmnet <- data.frame(Actual = Yt, Predicted = predMin, Dataset = dataset_name, Seed = rnd_seed)
  write.table(eval_glmnet,file = "glmnet_var_imp.csv", append = T, row.names = F, col.names = F)
  
  # print(data.frame(Name=dataset_name,
  #                  RMSE=performance[["RMSE"]],
  #                  MAE =performance[["MAE"]],
  #                  R_2 =performance[["r_squared"]],
  # 
  #                  NumSelected=numSelectedMin,
  #                  YLength=length(Y), YtLength=length(Yt),
  #                  YSum=sum(Y), YtSum=sum(Yt)))
  
  if (onlyRegression) {
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],
                       NumSelected=numSelectedMin,
                       YLength=length(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt),
                       Pred_Vars=paste(variables,sep="",collapse=","), stringsAsFactors = F)
  }else{
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],
                       # THRES_DT2 = performance[["THRES_DT2"]],
                       THRES_preDT2 = performance[["THRES_preDT2"]],
                       # AUC_DT2=performance[["AUC_DT2"]],
                       AUC_preDT2=performance[["AUC_preDT2"]],
                       
                       # AUPRC_DT2=performance[["AUPRC_DT2"]],
                       AUPRC_preDT2=performance[["AUPRC_preDT2"]],
                       
                       # F1_DT2=performance[["F1_DT2"]],
                       F1_preDT2=performance[["F1_preDT2"]],
                       
                       # SENS_DT2=performance[["SENS_DT2"]],
                       SENS_preDT2=performance[["SENS_preDT2"]],
                       
                       # PPV_DT2=performance[["PPV_DT2"]],
                       PPV_preDT2=performance[["PPV_preDT2"]],              
                       
                       NPV_preDT2=performance[["NPV_preDT2"]],              
                       SPEC_preDT2=performance[["SPEC_preDT2"]],
                       percPos = performance[["percPos"]],
                       
                       NumSelected=numSelectedMin,
                       YLength=length(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt),
                       Pred_Vars=paste(variables,sep="",collapse=","), stringsAsFactors = F)
  }
  
  return(output)
}

eval_xgb <- data.frame(Actual = "Actual", Predicted = "Predicted", Dataset = "Dataset", Seed = "Seed")
write.table(eval_xgb,file = "xgb_var_imp.csv", append = T, row.names = F, col.names = T)
## Evaluate XGBoost
evalXGBoost <- function(X, Y, Xt, Yt, dataset_name, rnd_seed, onlyRegression=FALSE, returnFit = FALSE){ # , pen, pmax=NULL

  ptm <- proc.time()
  fit <- NULL
  set.seed(rnd_seed)
  
  Y = as.data.frame(Y)
  X = as.data.frame(X)
  data = cbind(X,Y)
  
  # create training and validation dataset
  inTrain <- createDataPartition(data$Y, p = 0.8, list = FALSE)
  train <- data[inTrain, ]
  val <- data[-inTrain, ]
  
  # training data
  Xtr = train[,-which(names(train)=="Y")]
  Ytr = train[, which(names(train)=="Y")]
  Xtr = as.matrix(Xtr)
  Ytr = as.matrix(Ytr)
  mode(Xtr) ="numeric"
  mode(Ytr) ="numeric"
  
  # validation data
  Xval = val[,-which(names(val)=="Y")]
  Yval = val[, which(names(val)=="Y")]
  Xval = as.matrix(Xval)
  Yval = as.matrix(Yval)
  mode(Xval) ="numeric"
  mode(Yval) ="numeric"
  
  dtrain <- xgb.DMatrix(Xtr, label = Ytr)
  dval <- xgb.DMatrix(Xval, label = Yval)
  
  watchlist <- list(eval = dval, train = dtrain)
  # detectCores()
  # library(parallel)
  param <- list(
    eta = 0.05, #learning rate
    silent = 1,
    nthread = detectCores() - 1, #4, 
    alpha = 50,
    objective = "reg:linear", eval_metric = "rmse", booster = "gbtree")
  
  # build model
  fit <- xgb.train(param, dtrain, nrounds = 5000, watchlist, verbose = F ,early_stopping_rounds = 50) #, weight= class_weights

  # ############ save values ###############
  features = xgb.importance(feature_names = names(Xt),model = fit)
  features = features[order(features$Feature,decreasing = F)]
  Var_name = features$Feature
  Var_value = features$Gain
  # ############   ############   ###########
  
  if(is.null(fit)) return(NULL)
  # time <- proc.time()-ptm
  # # print(time[3])
  
  if(returnFit){
    return(fit)
  }

  
  imp = xgb.importance(colnames(Xtr), model = fit)
  numSelectedMin = nrow(imp)
  variables = imp$Feature
  
  # Predict on test set
  Xt = as.matrix(Xt)
  predMin <- predict(fit, Xt)
  
  if(onlyRegression){
    performance = getPerformance_regression(predMin, Yt)
  }else{
    performance = getPerformance(predMin, Yt)
  }
  
  # save data ACTUAL vs PREDICTED
  eval_xgb <- data.frame(Actual = Var_name, Predicted = Var_value, Dataset = dataset_name, Seed = rnd_seed )
  # eval_xgb <- data.frame(Actual = Yt, Predicted = predMin, Dataset = dataset_name, Seed = rnd_seed)
  write.table(eval_xgb,file = "xgb_var_imp.csv", append = T, row.names = F, col.names = F)
  
  # print(data.frame(Name=dataset_name,
  #                  RMSE=performance[["RMSE"]],
  #                  MAE =performance[["MAE"]],
  #                  R_2 =performance[["r_squared"]],
  # 
  #                  NumSelected=numSelectedMin,
  #                  YLength=nrow(Y), YtLength=length(Yt),
  #                  YSum=sum(Y), YtSum=sum(Yt)))

  if (onlyRegression) {
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],

                       NumSelected=numSelectedMin,
                       YLength=nrow(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt),
                       Pred_Vars=paste(variables,sep="",collapse=","), stringsAsFactors = F)
  }else{
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],
                       # THRES_DT2 = performance[["THRES_DT2"]],
                       THRES_preDT2 = performance[["THRES_preDT2"]],
                       # AUC_DT2=performance[["AUC_DT2"]],
                       AUC_preDT2=performance[["AUC_preDT2"]],
                       
                       # AUPRC_DT2=performance[["AUPRC_DT2"]],
                       AUPRC_preDT2=performance[["AUPRC_preDT2"]],
                       
                       # F1_DT2=performance[["F1_DT2"]],
                       F1_preDT2=performance[["F1_preDT2"]],
                       
                       # SENS_DT2=performance[["SENS_DT2"]],
                       SENS_preDT2=performance[["SENS_preDT2"]],
                       
                       # PPV_DT2=performance[["PPV_DT2"]],
                       PPV_preDT2=performance[["PPV_preDT2"]],              
                       
                       NPV_preDT2=performance[["NPV_preDT2"]],              
                       SPEC_preDT2=performance[["SPEC_preDT2"]],
                       percPos = performance[["percPos"]],
                       
                       NumSelected=numSelectedMin,
                       YLength=nrow(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt),
                       Pred_Vars=paste(variables,sep="",collapse=","), stringsAsFactors = F)
  }
  
  
  return(output)
}



eval_rf <- data.frame(Actual = "Actual", Predicted = "Predicted", Dataset = "Dataset", Seed = "Seed")
write.table(eval_rf,file = "rf_var_imp.csv", append = T, row.names = F, col.names = T)
evalRF <-function(X, Y, Xt, Yt, dataset_name, rnd_seed, ntrees = 500, onlyRegression=FALSE, returnFit = FALSE){ # , pen, pmax=NULL
  
  n_cores = detectCores()-1
  each_core = round(ntrees/n_cores)
  each_core_fixed = c(rep(each_core,n_cores-1),ntrees - each_core*(n_cores-1))

  # ptm <- proc.time()
  
  # build model
  fit <- NULL
  
  set.seed(rnd_seed)
  
  # cl <- makeCluster(n_cores, type = "SOCK")
  # registerDoSNOW(cl)
  # 
  # fit <- foreach(ntree = each_core_fixed, .combine = combine,  .packages = "randomForest") %dopar% randomForest(X, Y, ntree = ntree, importance = T)
  # 
  # stopCluster(cl)
  # 
  # # Count selected features
  # coeff = fit$coefficients
  # coeff = coeff[-which(names(coeff)=="(Intercept)")]
  # numSelected <- nrow(fit$importance)
  #
  # # Features names
  # variables = row.names(fit$importance)
  # b = as.data.frame(fit$importance)
  # variables = b[order(b$`%IncMSE`,decreasing = T),]
  
  fit <-randomForest(X, Y, ntree = ntrees, importance = T)
  importance(fit)
  treesize(fit)
  hist(treesize(fit))
  
  if(is.null(fit)) return(NULL)

  if (returnFit) {
    return(fit)
  }
  # time <- proc.time()-ptm
  # print(time[3])
  
  imp = importance(fit)
  imp = as.data.frame(imp)

  # # ############ save values ###############
  ordered_imp = imp[order(row.names(imp), decreasing = F),]
  Var_name = row.names(ordered_imp)
  Var_value = as.double(ordered_imp$`%IncMSE`)
  # # ############   ############   ###########
  
  imp = imp[order(imp$`%IncMSE`, decreasing = T),]
  variables = row.names(imp)
  numSelected = nrow(imp)

  # Predict on test set
  predMin <- predict(fit, type="response", Xt)
  
  if(onlyRegression){
    performance = getPerformance_regression(predMin, Yt)
  }else{
    performance = getPerformance(predMin, Yt)
  }
  
  if(is.null(performance)){
    return(NULL)
  }
  
  # save data ACTUAL vs PREDICTED
  eval_rf <- data.frame(Actual = Var_name, Predicted = Var_value, Dataset = dataset_name, Seed = rnd_seed )
  # eval_rf <- data.frame(Actual = Yt, Predicted = predMin, Dataset = dataset_name, Seed = rnd_seed)
  write.table(eval_rf,file = "rf_var_imp.csv", append = T, row.names = F, col.names = F)
  
  # print(data.frame(Name=dataset_name,
  #                  RMSE=performance[["RMSE"]],
  #                  MAE =performance[["MAE"]],
  #                  R_2 =performance[["r_squared"]],
  #                  NumSelected=numSelected,
  #                  YLength=length(Y), YtLength=length(Yt),
  #                  YSum=sum(Y), YtSum=sum(Yt)))
  
  if (onlyRegression) {
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],

                       NumSelected=numSelected,
                       YLength=length(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt),
                       Pred_Vars=paste(variables,sep="",collapse=","), stringsAsFactors = F)
  }else{
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],
                       # THRES_DT2 = performance[["THRES_DT2"]],
                       THRES_preDT2 = performance[["THRES_preDT2"]],
                       # AUC_DT2=performance[["AUC_DT2"]],
                       AUC_preDT2=performance[["AUC_preDT2"]],
                       
                       # AUPRC_DT2=performance[["AUPRC_DT2"]],
                       AUPRC_preDT2=performance[["AUPRC_preDT2"]],
                       
                       # F1_DT2=performance[["F1_DT2"]],
                       F1_preDT2=performance[["F1_preDT2"]],
                       
                       # SENS_DT2=performance[["SENS_DT2"]],
                       SENS_preDT2=performance[["SENS_preDT2"]],
                       
                       # PPV_DT2=performance[["PPV_DT2"]],
                       PPV_preDT2=performance[["PPV_preDT2"]],              
                       
                       NPV_preDT2=performance[["NPV_preDT2"]],              
                       SPEC_preDT2=performance[["SPEC_preDT2"]],
                       percPos = performance[["percPos"]],
                       
                       NumSelected=numSelected,
                       YLength=length(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt),
                       Pred_Vars=paste(variables,sep="",collapse=","), stringsAsFactors = F)
  }
  
  return(output)
}


eval_lightgbm <- data.frame(Actual = "Actual", Predicted = "Predicted", Dataset = "Dataset", Seed = "Seed")
write.table(eval_lightgbm,file = "lightgbm_var_imp.csv", append = T, row.names = F, col.names = T)

## Evaluate lightgbm 
source("lgb.importance.R")

evalLightGBM_new <- function(X, Y, Xt, Yt, alpha, dataset_name, rnd_seed, pen, onlyRegression=FALSE, returnFit = FALSE) {
  # ptm <- proc.time()
  set.seed(rnd_seed)

  # transform to matrices
  X = as.matrix(X)
  mode(X) ="numeric" # convert matrix to numeric
  Xt = as.matrix(Xt)
  mode(Xt) ="numeric" # convert matrix to numeric
  
  dtrain <- lgb.Dataset(X, label=Y)

  params = list(objective = "regression_l1")


  fit <- lgb.train(params, dtrain, 
                     nthread = detectCores()-1,
                     nrounds = 5000, 
                     verbose= 0
                     )
  
  importance = lgb.importance(fit, percentage = TRUE)
  variables = importance$Feature
  
  # ############ save values ###############
  ordered_imp = importance[order(importance$Feature, decreasing = F),]
  Var_name = ordered_imp$Feature
  Var_value = as.double(ordered_imp$Gain)
  # ############   ############   ###########

  if(is.null(fit)) return(NULL)
  
  if (returnFit) {
    return(fit)
  }
  # time <- proc.time()-ptm
  # print(time)
  
  # Predict on test set
  predMin <- predict(fit, Xt)
  
  if(onlyRegression){
    performance = getPerformance_regression(predMin, Yt)
  }else{
    performance = getPerformance(predMin, Yt)
  }
  
  if(is.null(performance)){
    return(NULL)
  }
  
  # save data ACTUAL vs PREDICTED
  eval_lightgbm <- data.frame(Actual = Var_name, Predicted = Var_value, Dataset = dataset_name, Seed = rnd_seed )
  # eval_lightgbm <- data.frame(Actual = Yt, Predicted = predMin, Dataset = dataset_name, Seed = rnd_seed)
  write.table(eval_lightgbm,file = "lightgbm_var_imp.csv", append = T, row.names = F, col.names = F)
  
  # print(data.frame(Name=dataset_name,
  #                  RMSE=performance[["RMSE"]],
  #                  MAE =performance[["MAE"]],
  #                  R_2 =performance[["r_squared"]],
  # 
  #                  NumSelected=numSelectedMin,
  #                  YLength=length(Y), YtLength=length(Yt),
  #                  YSum=sum(Y), YtSum=sum(Yt)))
  
  if (onlyRegression) {
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],
                       YLength=length(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt), 
                       Pred_Vars=paste(variables,sep="",collapse=","), stringsAsFactors = F)
  }else{
    output<-data.frame(Name=dataset_name,
                       RMSE=performance[["RMSE"]],
                       MAE =performance[["MAE"]],
                       R_2 =performance[["r_squared"]],
                       # THRES_DT2 = performance[["THRES_DT2"]],
                       THRES_preDT2 = performance[["THRES_preDT2"]],
                       # AUC_DT2=performance[["AUC_DT2"]],
                       AUC_preDT2=performance[["AUC_preDT2"]],
                       
                       # AUPRC_DT2=performance[["AUPRC_DT2"]],
                       AUPRC_preDT2=performance[["AUPRC_preDT2"]],
                       
                       # F1_DT2=performance[["F1_DT2"]],
                       F1_preDT2=performance[["F1_preDT2"]],
                       
                       # SENS_DT2=performance[["SENS_DT2"]],
                       SENS_preDT2=performance[["SENS_preDT2"]],
                       
                       # PPV_DT2=performance[["PPV_DT2"]],
                       PPV_preDT2=performance[["PPV_preDT2"]],              
                       
                       NPV_preDT2=performance[["NPV_preDT2"]],              
                       SPEC_preDT2=performance[["SPEC_preDT2"]],
                       percPos = performance[["percPos"]],
                       
                       YLength=length(Y), YtLength=length(Yt),
                       YSum=sum(Y), YtSum=sum(Yt), 
                       Pred_Vars=paste(variables,sep="",collapse=","),stringsAsFactors = F)
  }
  
  return(output)
}

