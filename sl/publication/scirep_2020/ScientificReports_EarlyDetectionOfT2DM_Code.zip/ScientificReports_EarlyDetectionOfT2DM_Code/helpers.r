
Sampling <- function(data, seed = NULL){
  set.seed(seed)
  
  data$PreDT2 <- 0
  data$PreDT2[data$class >= 6.1] <- 1
  negData <- data[data$PreDT2==0,]
  posData <- data[data$PreDT2==1,]
  negData$PreDT2 <- NULL
  posData$PreDT2 <- NULL
  
  # First sample positives...
  ind <- sample(1:nrow(posData), replace = T)
  trainSamp <- posData[ind,]
  testSamp <- posData[-ind,]
  # ...then negatives
  ind <- sample(1:nrow(negData), replace = T)
  trainSamp <- rbind(trainSamp, negData[ind,])
  testSamp <- rbind(testSamp, negData[-ind,])
  
  X = trainSamp[,setdiff(names(trainSamp), "class")]
  Y = trainSamp$class
  
  Xt = testSamp[,setdiff(names(testSamp), "class")]
  Yt = testSamp$class

  return(list(X = X, Y = Y, Xt = Xt, Yt = Yt))
}