source("summarySE.R")
source("evalGLMNET v2.R")
source("helpers.r") # "Sampling(data, seed)" sampling with replacement method returns list(X = X, Y = Y, Xt = Xt, Yt = Yt)

data_6_months = as.data.frame(readRDS("data_6_preprocessedData_3xsd.rds"))
data_12_months = as.data.frame(readRDS("data_12_preprocessedData_3xsd.rds"))
data_18_months = as.data.frame(readRDS("data_18_preprocessedData_3xsd.rds"))
data_24_months = as.data.frame(readRDS("data_24_preprocessedData_3xsd.rds"))
data_30_months = as.data.frame(readRDS("data_30_preprocessedData_3xsd.rds"))

data_6_months$class = ifelse(data_6_months$class >= 6.1, 1, 0)
data_6_months$Izvajalec <- NULL
write.csv(data_6_months, "data_6_months.csv")

list_of_datas <- list(data_30 = data_30_months,
                      data_24 = data_24_months,
                      data_18 = data_18_months,
                      data_12 = data_12_months,
                      data_6 = data_6_months
)

range = c(1:100)
res_lm <- NULL
res_glmnet <- NULL
res_RF <- NULL
res_XGBoost <- NULL
res_LightGBM_new <- NULL

## For obtaining %positives
# perc_pos = c()
# data_name = c()

# monitor progress
total = length(list_of_datas) * 10 * length(range)
current_progress = 0

for (i in c(1:length(list_of_datas))) {
  list_of_datas[[i]]$Izvajalec <- NULL
}

for (data_idx in c(1:length(list_of_datas))) {
  
  dataset_name = names(list_of_datas[data_idx]) # name of current dataset
  print(paste0("Dataset: ", dataset_name, "   (", data_idx,"/",length(list_of_datas),")"))
  
  data = list_of_datas[[data_idx]] 
  
  for (rSeed in range) {
    print(paste0(rSeed,"/",max(range)))
    sampled_data = Sampling(data, rSeed)
    X = sampled_data$X
    Y = sampled_data$Y
    
    Xt = sampled_data$Xt
    Yt = sampled_data$Yt
    
    ###### For obtaining %positives ######
    # perc_pos = c(perc_pos, prop.table(table(ifelse(Yt>=6.1,1,0)))[[2]])
    # data_name = c(data_name, dataset_name)
    ######--------------------------######
    
    ##### LINEAR MODEL ######
    fit_lm <- evalLM(X = X, Y = Y, Xt = Xt, Yt = Yt, dataset_name = dataset_name, rnd_seed = rSeed, onlyRegression = FALSE)
    while (is.null(fit_lm)) {
      tmp_rSeed = rSeed+ max(range)
      print(paste0(tmp_rSeed,"/ tmp seed"))

      sampled_data = Sampling(data, tmp_rSeed)
      X_tmp = sampled_data$X
      Y_tmp = sampled_data$Y

      Xt_tmp = sampled_data$Xt
      Yt_tmp = sampled_data$Yt

      fit_lm <- evalLM(X = X_tmp, Y = Y_tmp, Xt = Xt_tmp, Yt = Yt_tmp, dataset_name = dataset_name, rnd_seed = tmp_rSeed, onlyRegression = FALSE)
    }
    if (!is.null(fit_lm)) {
      print("LM training completed")
    }
    ####--------------------------######
    
    # CONVERT TO MATRIX
    X = as.matrix(X)
    mode(X) ="numeric" # convert matrix to numeric
    Xt = as.matrix(Xt)
    mode(Xt) ="numeric" # convert matrix to numeric

    ###### GLMNET ######
    fit_glmnet <- evalGLMNET(X = X, Y = Y, Xt = Xt, Yt = Yt, alpha = 1, dataset_name = dataset_name, rnd_seed = rSeed, pen = rep(1, ncol(X)), onlyRegression = FALSE)
    if (!is.null(fit_glmnet)) {
      print("Glmnet training completed")
    }

    ###### RANDOM FOREST ######
    fit_RF <- evalRF(X = X, Y = Y, Xt = Xt, Yt = Yt, dataset_name = dataset_name, rnd_seed = rSeed, ntrees = 500, onlyRegression = FALSE)
    if (!is.null(fit_RF)) {
      print("RF training completed")
    }

    ###### XGBOOST ######
    fit_XGBoost <-  evalXGBoost(X = X, Y = Y, Xt = Xt, Yt = Yt, dataset_name = dataset_name, rnd_seed = rSeed, onlyRegression = FALSE)
    if (!is.null(fit_XGBoost)) {
      print("XGBoost training completed")
    }

    ###### LIGHT GBM ######
    fit_LightGBM_new <-  evalLightGBM_new(X = X, Y = Y, Xt = Xt, Yt = Yt, dataset_name = dataset_name, rnd_seed = rSeed, onlyRegression = FALSE)
    if (!is.null(fit_LightGBM_new)) {
      print("Light GBM training completed")
    }

    res_lm <- rbind(res_lm, fit_lm)
    res_glmnet <-rbind(res_glmnet, fit_glmnet)
    res_RF <-rbind(res_RF, fit_RF)
    res_XGBoost <-rbind(res_XGBoost, fit_XGBoost)
    res_LightGBM_new <- rbind(res_LightGBM_new, fit_LightGBM_new)
  }
}

# write.csv(res_lm, paste0("lm_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd_fixed.csv"))
# write.csv(res_glmnet, paste0("glmnet_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd_fixed.csv"))
# write.csv(res_XGBoost, paste0("XGBoost_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd_fixed.csv"))
# write.csv(res_RF, paste0("RF_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd_fixed.csv"))
# write.csv(res_LightGBM_new, paste0("LightGBM_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd_fixed.csv"))


write.csv(res_lm, paste0("lm_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd.csv"))
write.csv(res_glmnet, paste0("glmnet_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd.csv"))
write.csv(res_XGBoost, paste0("XGBoost_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd.csv"))
write.csv(res_RF, paste0("RF_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd.csv"))
write.csv(res_LightGBM_new, paste0("LightGBM_validationResults_completecases_w-o_Izvajalec_100_preprocessedData_3xsd.csv"))


# perc_pos_data = data.frame(PercPos = perc_pos,Period = data_name)
# write.csv(perc_pos_data, paste0("Actual_PercPos.csv"))
