library(MLmetrics) #PRAUC
library(pROC) #roc coords
library(caret) #postResample

# get classification perfomance
getPerf <- function(predCont, truthBin){

  # 'response' must have two levels
  if(length(levels(as.factor(truthBin)))!= 2){
    return(NULL)
  }
  result.roc <- roc(response = truthBin, predictor = as.numeric(predCont)) 
  result.coords <- coords(result.roc, "best", best.method="closest.topleft", 
                          ret=c("threshold", "accuracy", "sensitivity", "specificity", "ppv", "npv"))
  
  auprc <- PRAUC(y_true = truthBin, y_pred = as.numeric(predCont))

  # it might happen that method "coords" returns two or more results
  if (!is.null(dim(result.coords))) {
    if(dim(result.coords)[2] >1){
      res.cor = as.data.frame(result.coords)
      idx = which(res.cor[row.names(res.cor)=="sensitivity",] == max(res.cor[row.names(res.cor)=="sensitivity",]))
      result.coords = result.coords[,idx]
    }
  }
  percPos = sum((predCont > result.coords[1]))/length(predCont)
  f1=2*((result.coords[["sensitivity"]]*result.coords[["ppv"]])/(result.coords[["sensitivity"]]+result.coords[["ppv"]]))
  
  return(list(AUC = as.numeric(result.roc$auc), 
              AUPRC = as.numeric(auprc), 
              F1 = f1, 
              THRES = result.coords[["threshold"]], 
              SENS = result.coords[["sensitivity"]], 
              SPEC = result.coords[["specificity"]], 
              PPV = result.coords[["ppv"]],
              NPV = result.coords[["npv"]],
              percPos = percPos
  ))
}

getPerformance <- function(predCont, truth){
  
  # get regression perfomance
  perf = postResample(pred = predCont, obs = truth)
  rmse = perf[["RMSE"]]
  r_squared = perf[["Rsquared"]]
  mae = perf[["MAE"]]
  
  # get prediabetes and diabetes outcomes
  # truthBin_DT2 <- ifelse(truth >= 7, 1, 0)
  truthBin_predDT2 <- ifelse(truth >= 6.1, 1, 0)

  
  # print(table(truthBin_predDT2))
  # print(prop.table(table(truthBin_predDT2)))
  
  # get classification perfomance (calculate according to regression results)
  # DT2_perf = getPerf(predCont = predCont, truthBin = truthBin_DT2)
  preDT2_perf = getPerf(predCont = predCont, truthBin = truthBin_predDT2)
  
  if(is.null(preDT2_perf) ){ #|| is.null(DT2_perf)
    return(NULL)
  }
  
  # THRES_DT2 = DT2_perf[["THRES"]]
  # AUC_DT2 = DT2_perf[["AUC"]]
  # AUPRC_DT2 = DT2_perf[["AUPRC"]]
  # F1_DT2 = DT2_perf[["F1"]]
  # ACC_DT2 = DT2_perf[["ACC"]]
  # SENS_DT2 = DT2_perf[["SENS"]]
  # PPV_DT2 = DT2_perf[["PPV"]]
  
  THRES_preDT2 = preDT2_perf[["THRES"]]
  AUC_preDT2 = preDT2_perf[["AUC"]]
  AUPRC_preDT2 = preDT2_perf[["AUPRC"]]
  F1_preDT2 = preDT2_perf[["F1"]]
  ACC_preDT2 = preDT2_perf[["ACC"]]
  SENS_preDT2 = preDT2_perf[["SENS"]]
  SPEC_preDT2 = preDT2_perf[["SPEC"]]
  PPV_preDT2 = preDT2_perf[["PPV"]]
  NPV_preDT2 = preDT2_perf[["NPV"]]
  
  percPos = preDT2_perf[["percPos"]]
  
  
  return(list(RMSE = rmse,
              MAE = mae,
              r_squared = r_squared,
              # THRES_DT2 = THRES_DT2,
              THRES_preDT2 = THRES_preDT2,
              # AUC_DT2 = AUC_DT2,
              AUC_preDT2 = AUC_preDT2,
              # AUPRC_DT2 = AUPRC_DT2,
              AUPRC_preDT2 = AUPRC_preDT2,
              # F1_DT2 = F1_DT2,
              F1_preDT2 = F1_preDT2,
              # SENS_DT2 = SENS_DT2,
              SENS_preDT2 = SENS_preDT2,
              SPEC_preDT2 = SPEC_preDT2,
              # PPV_DT2 = PPV_DT2,
              PPV_preDT2 = PPV_preDT2,
              NPV_preDT2 = NPV_preDT2,
              percPos = percPos
              
  ))
}


getPerformance_regression <- function(predCont, truth){
  
  # get regression perfomance
  perf = postResample(pred = predCont, obs = truth)
  rmse = perf[["RMSE"]]
  r_squared = perf[["Rsquared"]]
  mae = perf[["MAE"]]
  
  return(list(RMSE = rmse,
              MAE = mae,
              r_squared = r_squared
  ))
}